library(testthat)
library(mgrf)

test_check("mgrf")